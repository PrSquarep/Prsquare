from django.apps import AppConfig


class PrConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pr'
