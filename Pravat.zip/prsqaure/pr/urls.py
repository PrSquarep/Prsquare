from django.urls import path
from django.urls.resolvers import URLPattern
from . import views

urlpatterns = [
    path('',views.home, name='home'),
    path('products/', views.products, name='products'),
    path("services/", views.services, name='services'),
    path('contact/',views.contact, name='contact'),
   
]
