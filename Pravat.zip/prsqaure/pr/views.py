from django.shortcuts import render
from django.http import HttpResponse, request


# Create your views here.
def home(request):
    return render(request, 'index.html')
def products(request):
    return render(request,'products.html')
def services(request):
    return render(request, 'services.html')
def contact(request):
    return render(request, 'contact.html')
    






